# Contributors to Impact Installer

@LeafHacker <leaf@impactclient.net>
@leijurv <leijurv@impactclient.net>
Brady (@ZeroMemes) <brady@impactclient.net>